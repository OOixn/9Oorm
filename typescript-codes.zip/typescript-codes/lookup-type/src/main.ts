import { Car } from "./third-party";

function updateCarBrand(id: Car["id"], newBrand: Car["brand"]) {}
