let username = "John";

console.log(username);
